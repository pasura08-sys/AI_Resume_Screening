import re
from typing import Dict, List

from .algorithms.kmp import kmp_search
from .algorithms.edit_distance import edit_distance
from .algorithms.aho_corasick import AhoCorasick


def normalize_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text: str) -> List[str]:
    return normalize_text(text).split()


def word_boundary_match(text: str, skill: str) -> bool:
    """Avoid treating a skill such as 'sql' as a match inside 'mysql'."""
    normalized_text = normalize_text(text)
    normalized_skill = normalize_text(skill)
    if not normalized_skill:
        return False
    pattern = r"(?<![a-z0-9+#])" + re.escape(normalized_skill) + r"(?![a-z0-9+#])"
    return re.search(pattern, normalized_text) is not None


def fuzzy_skill_match(resume: str, skill: str, threshold: float = 0.70):
    skill_tokens = tokenize(skill)
    resume_tokens = tokenize(resume)
    if not skill_tokens or not resume_tokens:
        return 0.0, "No Match", ""

    target = " ".join(skill_tokens)
    k = len(skill_tokens)
    best_similarity = 0.0
    best_text = ""

    for i in range(len(resume_tokens) - k + 1):
        candidate = " ".join(resume_tokens[i:i + k])
        distance = edit_distance(target, candidate)
        similarity = 1 - distance / max(len(target), len(candidate), 1)
        if similarity > best_similarity:
            best_similarity = similarity
            best_text = candidate

    if best_similarity >= 0.999:
        return 1.0, "Exact Match", best_text
    if best_similarity >= threshold:
        return best_similarity, "Close Match", best_text
    return best_similarity, "No Match", best_text


def screen_resume(resume_text: str, required_skills: List[str]) -> Dict:
    resume = normalize_text(resume_text)
    skills = [s.strip() for s in required_skills if s.strip()]
    skills = list(dict.fromkeys(skills))

    # Aho-Corasick finds all required skills in one multi-pattern search.
    automaton = AhoCorasick(skills)
    aho_found = automaton.search(resume)

    details = []
    exact_count = 0
    fuzzy_count = 0
    total = 0.0

    for skill in skills:
        # KMP is retained as the explicit exact pattern-matching algorithm.
        # Word boundaries make the recruiter result more meaningful.
        exact = word_boundary_match(resume, skill) and kmp_search(resume, normalize_text(skill))
        aho_exact = normalize_text(skill) in aho_found and word_boundary_match(resume, skill)

        if exact or aho_exact:
            exact_count += 1
            total += 1.0
            details.append({
                "skill": skill,
                "status": "Exact Match",
                "similarity": 1.0,
                "matched_text": skill,
                "method": "KMP + Aho-Corasick",
            })
            continue

        similarity, status, matched_text = fuzzy_skill_match(resume, skill)
        if status == "Close Match":
            fuzzy_count += 1
            total += similarity
            details.append({
                "skill": skill,
                "status": "Close Match",
                "similarity": round(similarity, 4),
                "matched_text": matched_text,
                "method": "Edit Distance",
            })
        else:
            details.append({
                "skill": skill,
                "status": "Missing",
                "similarity": round(similarity, 4),
                "matched_text": matched_text,
                "method": "Edit Distance",
            })

    score = (total / len(skills) * 100) if skills else 0.0
    matched = [d["skill"] for d in details if d["status"] in ("Exact Match", "Close Match")]
    missing = [d["skill"] for d in details if d["status"] == "Missing"]

    return {
        "score": round(score, 2),
        "matched_skills": matched,
        "missing_skills": missing,
        "exact_count": exact_count,
        "fuzzy_count": fuzzy_count,
        "details": details,
        "algorithms": ["KMP", "Aho-Corasick", "Wagner-Fischer Edit Distance"],
    }


def rank_candidates(candidates: List[Dict]) -> List[Dict]:
    ranked = sorted(candidates, key=lambda item: item["score"], reverse=True)
    for index, item in enumerate(ranked, 1):
        item["rank"] = index
    return ranked
