from pathlib import Path
import re
import io

from fastapi import FastAPI, File, Form, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from algorithms.kmp import kmp_search
from algorithms.aho_corasick import AhoCorasick
from algorithms.edit_distance import similar_word


app = FastAPI(title="Resume Screening API")


# Allow the React frontend to communicate with Python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def clean_words(text):
    return re.findall(r"[a-zA-Z][a-zA-Z+#.-]*", text.lower())


def fuzzy_matches(skills, text, exact_matches):
    words = clean_words(text)
    fuzzy = []

    for skill in skills:

        # Skip skills that were already found exactly
        if skill.lower() in exact_matches:
            continue

        skill_words = skill.lower().split()

        # Compare single-word skills with resume words
        if len(skill_words) == 1:
            for word in words:
                if similar_word(skill_words[0], word):
                    fuzzy.append(skill)
                    break

    return fuzzy


def screen_resume(resume_text, skills):

    skills = [s.strip() for s in skills if s.strip()]

    # -----------------------------------
    # 1. AHO-CORASICK
    # Search all skills together
    # -----------------------------------

    aho = AhoCorasick(skills)
    aho_matches = aho.search(resume_text)

    # -----------------------------------
    # 2. KMP
    # Confirm exact matches individually
    # -----------------------------------

    exact = []

    for skill in skills:
        if kmp_search(resume_text, skill):
            exact.append(skill)

    exact_set = {skill.lower() for skill in exact}

    # -----------------------------------
    # 3. EDIT DISTANCE
    # Find approximate/fuzzy matches
    # -----------------------------------

    fuzzy = fuzzy_matches(
        skills,
        resume_text,
        exact_set
    )

    fuzzy_set = {skill.lower() for skill in fuzzy}

    # -----------------------------------
    # 4. FIND MISSING SKILLS
    # -----------------------------------

    missing = [
        skill
        for skill in skills
        if skill.lower() not in exact_set
        and skill.lower() not in fuzzy_set
    ]

    # -----------------------------------
    # 5. CALCULATE SCORE
    #
    # Exact match = 1 point
    # Fuzzy match = 0.5 point
    # -----------------------------------

    score = 0

    if skills:
        score = round(
            (
                (len(exact) + 0.5 * len(fuzzy))
                / len(skills)
            ) * 100
        )

    return {
        "score": score,
        "exact_matches": exact,
        "multi_matches": sorted(aho_matches),
        "fuzzy_matches": fuzzy,
        "missing_skills": missing,
    }


def extract_text(filename, content):

    extension = Path(filename).suffix.lower()

    # -----------------------------------
    # TXT FILE
    # -----------------------------------

    if extension == ".txt":
        return content.decode(
            "utf-8",
            errors="ignore"
        )

    # -----------------------------------
    # PDF FILE
    # -----------------------------------

    if extension == ".pdf":

        try:
            from pypdf import PdfReader

            reader = PdfReader(
                io.BytesIO(content)
            )

            return "\n".join(
                page.extract_text() or ""
                for page in reader.pages
            )

        except Exception:
            return ""

    # -----------------------------------
    # WORD DOCX FILE
    # -----------------------------------

    if extension == ".docx":

        try:
            from docx import Document

            document = Document(
                io.BytesIO(content)
            )

            return "\n".join(
                paragraph.text
                for paragraph in document.paragraphs
            )

        except Exception:
            return ""

    # -----------------------------------
    # FALLBACK
    # -----------------------------------

    return content.decode(
        "utf-8",
        errors="ignore"
    )


@app.get("/")
def home():

    return {
        "message": "Resume Screening API is running"
    }


@app.post("/screen")
async def screen(

    job_title: str = Form(...),

    skills: str = Form(...),

    resumes: list[UploadFile] = File(...),

):

    # Convert:
    #
    # "Python, SQL, Pandas"
    #
    # into:
    #
    # ["Python", "SQL", "Pandas"]

    skill_list = [
        skill.strip()
        for skill in skills.split(",")
        if skill.strip()
    ]

    results = []

    # Process every uploaded resume

    for resume in resumes:

        # Read the uploaded file

        content = await resume.read()

        # Extract text from TXT/PDF/DOCX

        text = extract_text(
            resume.filename,
            content
        )

        # Run the DSA screening

        result = screen_resume(
            text,
            skill_list
        )

        # Add filename to result

        result["filename"] = resume.filename

        results.append(result)

    # -----------------------------------
    # RANK CANDIDATES
    # Highest score first
    # -----------------------------------

    results.sort(
        key=lambda item: item["score"],
        reverse=True
    )

    # Add ranking numbers

    for index, result in enumerate(
        results,
        start=1
    ):

        result["rank"] = index

    # Send results back to React

    return {
        "job_title": job_title,
        "required_skills": skill_list,
        "candidates": results,
    }