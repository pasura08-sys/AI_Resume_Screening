def edit_distance(a, b):
    a = a.lower()
    b = b.lower()

    dp = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]

    for i in range(len(a) + 1):
        dp[i][0] = i
    for j in range(len(b) + 1):
        dp[0][j] = j

    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(
                    dp[i - 1][j],
                    dp[i][j - 1],
                    dp[i - 1][j - 1]
                )

    return dp[-1][-1]


def similar_word(word1, word2, threshold=0.25):
    distance = edit_distance(word1, word2)
    longest = max(len(word1), len(word2))

    if longest == 0:
        return True

    return distance / longest <= threshold
