from collections import deque


class AhoCorasick:
    def __init__(self, patterns):
        self.next = [{}]
        self.fail = [0]
        self.output = [[]]
        self.patterns = [p.lower() for p in patterns if p.strip()]

        for index, pattern in enumerate(self.patterns):
            node = 0
            for char in pattern:
                if char not in self.next[node]:
                    self.next[node][char] = len(self.next)
                    self.next.append({})
                    self.fail.append(0)
                    self.output.append([])
                node = self.next[node][char]
            self.output[node].append(index)

        queue = deque()
        for node in self.next[0].values():
            queue.append(node)

        while queue:
            current = queue.popleft()
            for char, child in self.next[current].items():
                queue.append(child)
                fallback = self.fail[current]

                while fallback and char not in self.next[fallback]:
                    fallback = self.fail[fallback]

                self.fail[child] = self.next[fallback].get(char, 0)
                self.output[child].extend(self.output[self.fail[child]])

    def search(self, text):
        text = text.lower()
        found = set()
        node = 0

        for char in text:
            while node and char not in self.next[node]:
                node = self.fail[node]

            node = self.next[node].get(char, 0)

            for pattern_index in self.output[node]:
                found.add(self.patterns[pattern_index])

        return found
