def build_lps(pattern):
    lps = [0] * len(pattern)
    length = 0
    i = 1

    while i < len(pattern):
        if pattern[i] == pattern[length]:
            length += 1
            lps[i] = length
            i += 1
        elif length > 0:
            length = lps[length - 1]
        else:
            i += 1

    return lps


def kmp_search(text, pattern):
    text = text.lower()
    pattern = pattern.lower()

    if not pattern:
        return False

    lps = build_lps(pattern)
    i = j = 0

    while i < len(text):
        if text[i] == pattern[j]:
            i += 1
            j += 1

            if j == len(pattern):
                return True
        elif j > 0:
            j = lps[j - 1]
        else:
            i += 1

    return False
