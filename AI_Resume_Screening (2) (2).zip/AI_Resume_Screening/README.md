# AI Resume Screening System

A beginner-friendly recruiter-side resume screening project using **React + Python FastAPI**.

## What it does

1. Recruiter enters a job title and required skills.
2. Recruiter uploads multiple `.txt` or `.pdf` resumes.
3. Python screens every resume using:
   - **KMP** — exact skill matching
   - **Aho-Corasick** — matching many skills together
   - **Edit Distance** — fuzzy matching for small variations
4. The system calculates a match score.
5. Candidates are ranked from highest to lowest score.
6. React displays matched, fuzzy, and missing skills.

## Project structure

```text
AI_Resume_Screening/
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   └── algorithms/
│       ├── kmp.py
│       ├── aho_corasick.py
│       └── edit_distance.py
└── frontend/
    ├── package.json
    ├── index.html
    └── src/
        ├── main.jsx
        └── style.css
```

## Run backend

Open Terminal 1:

```bash
cd backend
python -m venv .venv
```

Windows:

```bash
.venv\\Scripts\\activate
```

Then:

```bash
pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000
```

## Run frontend

Open Terminal 2:

```bash
cd frontend
npm install
npm run dev
```

Open the URL shown by Vite, normally `http://localhost:5173`.

## Review explanation

**React:** recruiter interface.

**FastAPI:** connects the website to the Python algorithms.

**KMP:** checks exact required skills.

**Aho-Corasick:** checks many required skills efficiently in the resume text.

**Edit Distance:** finds small variations when an exact match is not found.

**Scoring:** exact match = 1 point; fuzzy match = 0.5 point.

**Ranking:** candidates are sorted by their final percentage score.

No AI/NLP, database, authentication, or advanced assignment algorithm is required in this version.
