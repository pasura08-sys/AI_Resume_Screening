import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  const [jobTitle, setJobTitle] = useState("Python Developer");
  const [skills, setSkills] = useState(
    "Python, SQL, Pandas, NumPy, Machine Learning"
  );
  const [files, setFiles] = useState([]);
  const [results, setResults] = useState(null);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function screenCandidates() {
    if (!jobTitle || !skills || files.length === 0) {
      setError("Enter the job details and upload at least one resume.");
      return;
    }

    setLoading(true);
    setError("");
    setResults(null);
    setSelected(null);

    const form = new FormData();
    form.append("job_title", jobTitle);
    form.append("skills", skills);

    files.forEach((file) => {
      form.append("resumes", file);
    });

    try {
      const response = await fetch("http://127.0.0.1:8000/screen", {
        method: "POST",
        body: form,
      });

      if (!response.ok) {
        throw new Error("Screening failed");
      }

      const data = await response.json();

      setResults(data);
      setSelected(data.candidates[0] || null);
    } catch (err) {
      setError(
        "Could not connect to the Python backend. Make sure it is running on port 8000."
      );
    } finally {
      setLoading(false);
    }
  }

  function handleFileChange(event) {
    const selectedFiles = Array.from(event.target.files);
    setFiles(selectedFiles);
  }

  function removeFile(index) {
    setFiles(files.filter((_, i) => i !== index));
  }

  function getMatchLabel(score) {
    if (score >= 80) return "Strong Match";
    if (score >= 60) return "Good Match";
    if (score >= 40) return "Moderate Match";
    return "Low Match";
  }

  const averageScore =
    results && results.candidates.length > 0
      ? Math.round(
          results.candidates.reduce(
            (total, candidate) => total + candidate.score,
            0
          ) / results.candidates.length
        )
      : 0;

  return (
    <div className="app">
      <header className="hero">
        <div>
          <p className="eyebrow">RECRUITER TOOL</p>
          <h1>Resume Screening System</h1>
          <p className="subtitle">
            Screen and rank candidates using efficient DSA-based matching.
          </p>
        </div>
      </header>

      <main>
        {/* JOB SETUP */}
        <section className="card setup">
          <div className="section-heading">
            <div>
              <span className="section-number">01</span>
              <h2>Create Job</h2>
            </div>
          </div>

          <label>Job Title</label>
          <input
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            placeholder="e.g. Python Developer"
          />

          <label>Required Skills</label>
          <input
            value={skills}
            onChange={(e) => setSkills(e.target.value)}
            placeholder="Python, SQL, React"
          />
          <small>Separate skills with commas.</small>

          <label>Upload Resumes</label>

          <div className="upload-area">
            <input
              id="resume-upload"
              type="file"
              multiple
              accept=".txt,.pdf,.docx"
              onChange={handleFileChange}
            />

            <label htmlFor="resume-upload" className="upload-button">
              📁 Choose Resumes
            </label>

            <p>Upload multiple .PDF, .DOCX or .TXT resumes</p>
          </div>

          {files.length > 0 && (
            <div className="selected-files">
              <div className="selected-header">
                <strong>{files.length} resume(s) selected</strong>
              </div>

              {files.map((file, index) => (
                <div className="file-item" key={`${file.name}-${index}`}>
                  <span>📄 {file.name}</span>

                  <button
                    type="button"
                    onClick={() => removeFile(index)}
                    className="remove-file"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          <button
            className="screen-button"
            onClick={screenCandidates}
            disabled={loading}
          >
            {loading ? "Screening..." : "Screen Candidates →"}
          </button>

          {error && <p className="error">{error}</p>}
        </section>

        {/* RESULTS */}
        {results && (
          <section className="card results">
            <div className="results-header">
              <div>
                <span className="section-number">02</span>
                <h2>Candidate Ranking</h2>
                <p>
                  {results.job_title} · {results.candidates.length} candidate(s)
                </p>
              </div>

              <div className="skills-summary">
                {results.required_skills.join(" · ")}
              </div>
            </div>

            {/* STATS */}
            <div className="stats">
              <div className="stat-card">
                <span>👥</span>
                <div>
                  <strong>{results.candidates.length}</strong>
                  <small>Candidates</small>
                </div>
              </div>

              <div className="stat-card">
                <span>⭐</span>
                <div>
                  <strong>
                    {results.candidates[0]?.score || 0}%
                  </strong>
                  <small>Top Match</small>
                </div>
              </div>

              <div className="stat-card">
                <span>🎯</span>
                <div>
                  <strong>{averageScore}%</strong>
                  <small>Average Match</small>
                </div>
              </div>
            </div>

            {/* CANDIDATES */}
            <div className="candidate-list">
              {results.candidates.map((candidate) => (
                <button
                  className={`candidate ${
                    selected?.filename === candidate.filename
                      ? "candidate-selected"
                      : ""
                  }`}
                  key={candidate.filename}
                  onClick={() => setSelected(candidate)}
                >
                  <span className="rank">
                    {candidate.rank === 1
                      ? "🥇"
                      : candidate.rank === 2
                      ? "🥈"
                      : candidate.rank === 3
                      ? "🥉"
                      : `#${candidate.rank}`}
                  </span>

                  <span className="candidate-info">
                    <span className="name">{candidate.filename}</span>
                    <span className="match-label">
                      {getMatchLabel(candidate.score)}
                    </span>
                  </span>

                  <span className="bar">
                    <i style={{ width: `${candidate.score}%` }} />
                  </span>

                  <strong className="candidate-score">
                    {candidate.score}%
                  </strong>
                </button>
              ))}
            </div>

            {/* DETAILS */}
            {selected && (
              <div className="details">
                <div className="details-header">
                  <div>
                    <p className="candidate-label">SELECTED CANDIDATE</p>
                    <h3>{selected.filename}</h3>
                    <span className="match-badge">
                      {getMatchLabel(selected.score)}
                    </span>
                  </div>

                  <div className="big-score">
                    {selected.score}%
                    <small>match</small>
                  </div>
                </div>

                {/* BEST MATCHED SKILLS */}
                <div className="best-match">
                  <h4>⭐ Best-Matched Skills</h4>

                  {selected.exact_matches.length === 0 &&
                  selected.fuzzy_matches.length === 0 ? (
                    <p className="muted">No matching skills found.</p>
                  ) : (
                    <div className="best-skills-list">
                      {selected.exact_matches
                        .slice(0, 3)
                        .map((skill, index) => (
                          <div className="best-skill" key={skill}>
                            <span className="skill-number">
                              {index + 1}
                            </span>
                            <strong>{skill}</strong>
                            <span className="exact-label">
                              Exact match
                            </span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                <div className="detail-grid">
                  <Detail
                    title="✓ Other Matches"
                    items={[
                      ...selected.exact_matches.slice(3),
                      ...selected.fuzzy_matches,
                    ]}
                    good
                  />

                  <Detail
                    title="✗ Missing Skills"
                    items={selected.missing_skills}
                  />
                </div>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  );
}

function Detail({ title, items, good }) {
  return (
    <div className="detail-box">
      <h4>{title}</h4>

      {items.length === 0 ? (
        <p className="muted">None</p>
      ) : (
        <div>
          {items.map((item) => (
            <span
              className={good ? "tag good" : "tag missing"}
              key={item}
            >
              {item}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);