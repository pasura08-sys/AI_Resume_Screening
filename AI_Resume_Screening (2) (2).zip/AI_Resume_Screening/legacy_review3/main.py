# AI Resume Screening System - Review 3
# KMP + Rabin-Karp Rolling Hash + Edit Distance DP + Edmonds-Karp

import os
import re

from algorithms.kmp import kmp_search
from algorithms.rabin_karp import rolling_hash
from algorithms.edit_distance import edit_distance
from algorithms.flow_matching import maximum_candidate_job_matching


def read_file(filename):
    with open(filename, "r", encoding="utf-8") as file:
        return file.read().lower()


def normalize_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text):
    return normalize_text(text).split()


def detect_duplicates(resume_files):
    """Rabin-Karp style rolling-hash fingerprinting for exact duplicate resumes."""
    seen = {}
    duplicates = {}

    for filename in resume_files:
        normalized = normalize_text(read_file(filename))
        fingerprint = rolling_hash(normalized)

        # Verify equal hashes with equal normalized text to avoid hash-collision errors.
        if fingerprint in seen and seen[fingerprint][1] == normalized:
            duplicates[filename] = seen[fingerprint][0]
        else:
            seen[fingerprint] = (filename, normalized)

    return duplicates


def exact_skill_matches(resume, required_skills):
    matched = []
    for skill in required_skills:
        if kmp_search(resume, skill.lower()):
            matched.append(skill)
    return matched


def fuzzy_skill_match(resume, skill, threshold=0.70):
    """Compare a required skill with same-length token windows using edit distance."""
    skill_tokens = tokenize(skill)
    resume_tokens = tokenize(resume)

    if not skill_tokens or not resume_tokens:
        return 0.0, "No Match", ""

    k = len(skill_tokens)
    target = " ".join(skill_tokens)
    best_similarity = 0.0
    best_text = ""

    for i in range(len(resume_tokens) - k + 1):
        candidate = " ".join(resume_tokens[i:i + k])
        distance = edit_distance(target, candidate)
        similarity = 1 - distance / max(len(target), len(candidate), 1)

        if similarity > best_similarity:
            best_similarity = similarity
            best_text = candidate

    if best_similarity >= 0.999:
        return 1.0, "Exact", best_text
    if best_similarity >= threshold:
        return best_similarity, "Close Match", best_text
    return best_similarity, "No Match", best_text


def calculate_skill_score(resume, required_skills):
    exact = exact_skill_matches(resume, required_skills)
    details = []
    total = 0.0

    for skill in required_skills:
        if skill in exact:
            details.append((skill, "Exact Match", 1.0, skill))
            total += 1.0
        else:
            similarity, status, matched_text = fuzzy_skill_match(resume, skill)
            contribution = similarity if status == "Close Match" else 0.0
            total += contribution
            details.append((skill, status, similarity, matched_text))

    score = (total / len(required_skills) * 100) if required_skills else 0.0
    return score, details


def screen_resumes(resume_files, required_skills):
    duplicates = detect_duplicates(resume_files)
    unique_files = [f for f in resume_files if f not in duplicates]
    results = []

    for resume_file in unique_files:
        resume = read_file(resume_file)
        score, details = calculate_skill_score(resume, required_skills)
        results.append({
            "name": os.path.basename(resume_file),
            "path": resume_file,
            "score": score,
            "details": details,
        })

    results.sort(key=lambda item: item["score"], reverse=True)
    return duplicates, results


def main():
    base = os.path.dirname(os.path.abspath(__file__))
    resume_files = [
        os.path.join(base, "resumes", "resume1.txt"),
        os.path.join(base, "resumes", "resume2.txt"),
        os.path.join(base, "resumes", "resume3.txt"),
    ]

    required_skills = [
        "python", "sql", "machine learning", "data structures", "git"
    ]

    print("\nAI RESUME SCREENING SYSTEM - REVIEW 3")
    print("=" * 70)

    # Stage 1: duplicate filtering
    duplicates, results = screen_resumes(resume_files, required_skills)
    print("\n1. RABIN-KARP / ROLLING HASH - DUPLICATE DETECTION")
    print("-" * 70)
    if not duplicates:
        print("No duplicate resumes detected.")
    else:
        for duplicate, original in duplicates.items():
            print(f"{os.path.basename(duplicate)} -> DUPLICATE of {os.path.basename(original)}")

    # Stage 2: exact + fuzzy matching
    print("\n2. KMP + EDIT DISTANCE SKILL MATCHING")
    print("-" * 70)
    for item in results:
        print(f"\n{item['name']} -> Final Score: {item['score']:.2f}%")
        for skill, status, similarity, matched_text in item["details"]:
            if status == "Exact Match":
                print(f"  {skill:<20} -> Exact Match")
            elif status == "Close Match":
                print(f"  {skill:<20} -> Close Match ({similarity * 100:.2f}%) via '{matched_text}'")
            else:
                print(f"  {skill:<20} -> No Match")

    # Stage 3: ranking
    print("\n3. FINAL CANDIDATE RANKING")
    print("-" * 70)
    for rank, item in enumerate(results, start=1):
        print(f"{rank}. {item['name']} -> {item['score']:.2f}%")

    # Stage 4: multi-job compatibility table
    jobs = {
        "Python Developer": ["python", "sql", "git", "data structures"],
        "ML Intern": ["python", "machine learning", "data structures", "sql"],
        "Web Developer": ["html", "css", "java", "sql"],
    }

    score_table = {}
    print("\n4. CANDIDATE-JOB COMPATIBILITY")
    print("-" * 70)
    for item in results:
        resume = read_file(item["path"])
        score_table[item["name"]] = {}
        for job_name, skills in jobs.items():
            score, _ = calculate_skill_score(resume, skills)
            score_table[item["name"]][job_name] = score
        print(
            f"{item['name']}: " + ", ".join(
                f"{job}={score:.1f}%" for job, score in score_table[item["name"]].items()
            )
        )

    # Stage 5: network-flow assignment
    print("\n5. BIPARTITE MATCHING - EDMONDS-KARP")
    print("-" * 70)
    flow, assignments = maximum_candidate_job_matching(score_table, threshold=70.0)
    print(f"Maximum feasible assignments: {flow}")
    for candidate, job, score in assignments:
        print(f"{candidate} -> {job} ({score:.2f}%)")

    print("\n6. REVIEW 3 ALGORITHMS")
    print("-" * 70)
    print("KMP             : Exact skill matching")
    print("Rabin-Karp Hash : Duplicate resume detection")
    print("Edit Distance   : Fuzzy/near skill matching")
    print("Edmonds-Karp    : Candidate-job assignment")
    print("Sorting         : Final candidate ranking")


if __name__ == "__main__":
    main()
