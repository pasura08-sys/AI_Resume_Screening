# AI Resume Screening System - Review 3
# Advanced DSA implementation: KMP + Rabin-Karp Rolling Hash + Edit Distance DP + Edmonds-Karp Bipartite Matching

import os
import re
from collections import deque

from algorithms.kmp import kmp_search

# -----------------------------
# File handling / preprocessing
# -----------------------------

def read_file(filename):
    with open(filename, "r", encoding="utf-8") as file:
        return file.read().lower()


def normalize_text(text):
    text = text.lower()
    text = re.sub(r"[^a-z0-9+#.]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text):
    return normalize_text(text).split()


# -----------------------------
# 1. Rabin-Karp / Rolling Hash
# -----------------------------

RK_BASE = 257
RK_MOD = 1_000_000_007


def rolling_hash(text):
    """Polynomial rolling hash used as a document fingerprint."""
    h = 0
    for ch in text:
        h = (h * RK_BASE + ord(ch)) % RK_MOD
    return h


def detect_duplicates(resume_files):
    """Detect exact duplicate resumes using normalized rolling-hash fingerprints.
    Hash matches are verified with normalized text to avoid accepting a collision.
    """
    seen = {}
    duplicate_map = {}

    for filename in resume_files:
        normalized = normalize_text(read_file(filename))
        fingerprint = rolling_hash(normalized)

        if fingerprint in seen and seen[fingerprint][1] == normalized:
            duplicate_map[filename] = seen[fingerprint][0]
        else:
            seen[fingerprint] = (filename, normalized)

    return duplicate_map


# -----------------------------
# 2. KMP exact matching
# -----------------------------

def exact_skill_matches(resume, required_skills):
    matched = []
    for skill in required_skills:
        if kmp_search(resume, skill.lower()):
            matched.append(skill)
    return matched


# -----------------------------
# 3. Edit Distance / Wagner-Fischer DP
# -----------------------------

def edit_distance(a, b):
    """Levenshtein distance using the Wagner-Fischer DP recurrence."""
    a = a.lower()
    b = b.lower()

    prev = list(range(len(b) + 1))

    for i, ca in enumerate(a, start=1):
        curr = [i]
        for j, cb in enumerate(b, start=1):
            insert = curr[j - 1] + 1
            delete = prev[j] + 1
            replace = prev[j - 1] + (ca != cb)
            curr.append(min(insert, delete, replace))
        prev = curr

    return prev[-1]


def fuzzy_skill_match(resume, skill, threshold=0.70):
    """Find the closest same-length token window to a required skill."""
    skill_tokens = tokenize(skill)
    resume_tokens = tokenize(resume)

    if not skill_tokens or not resume_tokens:
        return 0.0, "No Match", ""

    k = len(skill_tokens)
    best_similarity = 0.0
    best_text = ""

    # Compare against windows with the same number of tokens as the skill.
    for i in range(len(resume_tokens) - k + 1):
        candidate = " ".join(resume_tokens[i:i + k])
        target = " ".join(skill_tokens)
        distance = edit_distance(target, candidate)
        denominator = max(len(target), len(candidate), 1)
        similarity = 1 - (distance / denominator)

        if similarity > best_similarity:
            best_similarity = similarity
            best_text = candidate

    if best_similarity >= 0.999:
        return 1.0, "Exact", best_text
    if best_similarity >= threshold:
        return best_similarity, "Close Match", best_text
    return best_similarity, "No Match", best_text


# -----------------------------
# 4. Combined candidate scoring
# -----------------------------

def calculate_skill_score(resume, required_skills):
    exact = exact_skill_matches(resume, required_skills)
    details = []
    total = 0.0

    for skill in required_skills:
        if skill in exact:
            details.append((skill, "Exact Match", 1.0, skill))
            total += 1.0
        else:
            similarity, status, matched_text = fuzzy_skill_match(resume, skill)
            # Count only acceptable close matches toward the score.
            contribution = similarity if status == "Close Match" else 0.0
            total += contribution
            details.append((skill, status, similarity, matched_text))

    score = (total / len(required_skills) * 100) if required_skills else 0.0
    return score, details


# -----------------------------
# 5. Bipartite matching using Edmonds-Karp
# -----------------------------

def add_edge(graph, u, v, capacity):
    graph[u][v] = capacity
    if u not in graph[v]:
        graph[v][u] = 0


def bfs_augmenting_path(graph, source, sink):
    parent = {source: None}
    queue = deque([source])

    while queue:
        u = queue.popleft()
        for v, capacity in graph[u].items():
            if capacity > 0 and v not in parent:
                parent[v] = u
                if v == sink:
                    return parent
                queue.append(v)

    return None


def edmonds_karp(graph, source, sink):
    max_flow = 0

    while True:
        parent = bfs_augmenting_path(graph, source, sink)
        if parent is None:
            break

        path_flow = float("inf")
        v = sink
        while v != source:
            u = parent[v]
            path_flow = min(path_flow, graph[u][v])
            v = u

        v = sink
        while v != source:
            u = parent[v]
            graph[u][v] -= path_flow
            graph[v][u] = graph[v].get(u, 0) + path_flow
            v = u

        max_flow += path_flow

    return int(max_flow), graph


def build_bipartite_matching(results, job_names, threshold=70.0):
    """Create candidate-job edges when candidate score reaches threshold.
    Each candidate and each job can be used at most once.
    """
    candidates = [item["name"] for item in results]
    score_lookup = {
        (item["name"], job): score
        for item in results
        for job, score in item["job_scores"].items()
    }

    source = "SOURCE"
    sink = "SINK"
    graph = {}

    def ensure(node):
        graph.setdefault(node, {})

    ensure(source)
    ensure(sink)

    candidate_nodes = {}
    job_nodes = {}

    for candidate in candidates:
        node = f"C::{candidate}"
        candidate_nodes[node] = candidate
        ensure(node)
        add_edge(graph, source, node, 1)

    for job in job_names:
        node = f"J::{job}"
        job_nodes[node] = job
        ensure(node)
        add_edge(graph, node, sink, 1)

    for candidate in candidates:
        cnode = f"C::{candidate}"
        for job in job_names:
            score = score_lookup[(candidate, job)]
            if score >= threshold:
                jnode = f"J::{job}"
                add_edge(graph, cnode, jnode, 1)

    # Add missing reverse nodes/edges so residual graph is explicit.
    for u in list(graph):
        for v in list(graph[u]):
            graph.setdefault(v, {})
            graph[v].setdefault(u, 0)

    max_flow, residual = edmonds_karp(graph, source, sink)

    assignments = []
    for cnode, candidate in candidate_nodes.items():
        for jnode, job in job_nodes.items():
            # Forward edge capacity becomes 0 when this edge is selected.
            # Reverse residual capacity becomes 1.
            if jnode in residual.get(cnode, {}) and residual[cnode][jnode] == 0:
                original_score = score_lookup[(candidate, job)]
                if original_score >= threshold and residual[jnode].get(cnode, 0) == 1:
                    assignments.append((candidate, job, original_score))

    assignments.sort(key=lambda x: x[2], reverse=True)
    return max_flow, assignments


# -----------------------------
# Main Review 3 pipeline
# -----------------------------

def screen_resumes(job_file, resume_files, required_skills):
    # Stage 1: duplicate detection
    duplicates = detect_duplicates(resume_files)
    unique_files = [f for f in resume_files if f not in duplicates]

    # Stage 2-4: preprocessing + KMP + Edit Distance scoring
    results = []
    for resume_file in unique_files:
        resume = read_file(resume_file)
        score, details = calculate_skill_score(resume, required_skills)
        results.append({
            "name": os.path.basename(resume_file),
            "path": resume_file,
            "score": score,
            "details": details,
            "job_scores": {}
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    return duplicates, results


def print_skill_details(results):
    print("\nSKILL MATCH DETAILS")
    print("=" * 70)
    for item in results:
        print(f"\n{item['name']} -> Final Score: {item['score']:.2f}%")
        for skill, status, similarity, matched_text in item["details"]:
            if status == "Exact Match":
                print(f"  {skill:<20} -> Exact Match")
            elif status == "Close Match":
                print(f"  {skill:<20} -> Close Match ({similarity * 100:.2f}%) via '{matched_text}'")
            else:
                print(f"  {skill:<20} -> No Match")


def main():
    base = os.path.dirname(os.path.abspath(__file__))
    job_file = os.path.join(base, "data", "job_description.txt")
    resume_files = [
        os.path.join(base, "resumes", "resume1.txt"),
        os.path.join(base, "resumes", "resume2.txt"),
        os.path.join(base, "resumes", "resume3.txt"),
    ]

    required_skills = [
        "python",
        "sql",
        "machine learning",
        "data structures",
        "git",
    ]

    print("\nAI RESUME SCREENING SYSTEM - REVIEW 3")
    print("=" * 70)

    # 1. Duplicate detection
    duplicates, results = screen_resumes(job_file, resume_files, required_skills)

    print("\n1. RABIN-KARP / ROLLING HASH - DUPLICATE DETECTION")
    print("-" * 70)
    if not duplicates:
        print("No duplicate resumes detected.")
    else:
        for duplicate, original in duplicates.items():
            print(f"{os.path.basename(duplicate)} -> DUPLICATE of {os.path.basename(original)}")

    # 2. Skill matching
    print_skill_details(results)

    # 3. Ranking
    print("\n2. FINAL CANDIDATE RANKING")
    print("-" * 70)
    for rank, item in enumerate(results, start=1):
        print(f"{rank}. {item['name']} -> {item['score']:.2f}%")

    # 4. Multi-job example for network-flow matching.
    # In the final project, these scores can come from separate job descriptions.
    jobs = {
        "Python Developer": ["python", "sql", "git", "data structures"],
        "ML Intern": ["python", "machine learning", "data structures", "sql"],
        "Web Developer": ["html", "css", "java", "sql"],
    }

    for item in results:
        resume = read_file(item["path"])
        for job_name, skills in jobs.items():
            item["job_scores"][job_name] = calculate_skill_score(resume, skills)[0]

    print("\n3. BIPARTITE CANDIDATE-JOB MATCHING (EDMONDS-KARP)")
    print("-" * 70)
    for item in results:
        print(f"{item['name']}: " + ", ".join(
            f"{job}={score:.1f}%" for job, score in item["job_scores"].items()
        ))

    flow, assignments = build_bipartite_matching(
        results,
        list(jobs.keys()),
        threshold=70.0
    )

    print(f"\nMaximum feasible assignments: {flow}")
    if assignments:
        for candidate, job, score in assignments:
            print(f"{candidate} -> {job} ({score:.2f}%)")
    else:
        print("No candidate-job assignment reached the 70% threshold.")

    print("\n4. REVIEW 3 SUMMARY")
    print("-" * 70)
    print("KMP             : Exact skill matching")
    print("Rabin-Karp Hash : Duplicate resume detection")
    print("Edit Distance   : Fuzzy/near skill matching")
    print("Edmonds-Karp    : Candidate-job bipartite assignment")
    print("Sorting         : Final candidate ranking")


if __name__ == "__main__":
    main()
