# Rabin-Karp / polynomial rolling hash utilities

BASE = 257
MOD = 1_000_000_007


def rolling_hash(text):
    h = 0
    for ch in text:
        h = (h * BASE + ord(ch)) % MOD
    return h


def rabin_karp_search(text, pattern):
    """Return starting indices of pattern in text using a rolling hash.
    Hash matches are verified character-by-character to avoid collision errors.
    """
    if pattern == "":
        return [0]
    if len(pattern) > len(text):
        return []

    m = len(pattern)
    high = pow(BASE, m - 1, MOD)
    pattern_hash = rolling_hash(pattern)
    window_hash = rolling_hash(text[:m])
    matches = []

    for i in range(len(text) - m + 1):
        if window_hash == pattern_hash and text[i:i + m] == pattern:
            matches.append(i)

        if i < len(text) - m:
            window_hash = (window_hash - ord(text[i]) * high) % MOD
            window_hash = (window_hash * BASE + ord(text[i + m])) % MOD

    return matches
