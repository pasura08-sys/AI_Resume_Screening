# Bipartite candidate-job matching using Edmonds-Karp max flow
from collections import deque


def add_edge(graph, u, v, capacity):
    graph.setdefault(u, {})
    graph.setdefault(v, {})
    graph[u][v] = capacity
    graph[v].setdefault(u, 0)


def bfs_augmenting_path(graph, source, sink):
    parent = {source: None}
    queue = deque([source])

    while queue:
        u = queue.popleft()
        for v, capacity in graph[u].items():
            if capacity > 0 and v not in parent:
                parent[v] = u
                if v == sink:
                    return parent
                queue.append(v)
    return None


def edmonds_karp(graph, source, sink):
    max_flow = 0

    while True:
        parent = bfs_augmenting_path(graph, source, sink)
        if parent is None:
            break

        path_flow = float("inf")
        v = sink
        while v != source:
            u = parent[v]
            path_flow = min(path_flow, graph[u][v])
            v = u

        v = sink
        while v != source:
            u = parent[v]
            graph[u][v] -= path_flow
            graph[v][u] = graph[v].get(u, 0) + path_flow
            v = u

        max_flow += path_flow

    return int(max_flow), graph


def maximum_candidate_job_matching(score_table, threshold=70.0):
    """score_table: {candidate: {job: score}}.
    An edge exists when score >= threshold. Each candidate/job is used once.
    Returns maximum number of assignments and selected assignments.
    """
    source, sink = "SOURCE", "SINK"
    graph = {}
    candidates = list(score_table.keys())
    jobs = sorted({job for scores in score_table.values() for job in scores})

    for candidate in candidates:
        add_edge(graph, source, f"C::{candidate}", 1)

    for job in jobs:
        add_edge(graph, f"J::{job}", sink, 1)

    for candidate, scores in score_table.items():
        for job, score in scores.items():
            if score >= threshold:
                add_edge(graph, f"C::{candidate}", f"J::{job}", 1)

    flow, residual = edmonds_karp(graph, source, sink)
    assignments = []

    for candidate in candidates:
        cnode = f"C::{candidate}"
        for job in jobs:
            jnode = f"J::{job}"
            # Selected forward edge has residual capacity 0 and reverse capacity 1.
            if residual.get(cnode, {}).get(jnode) == 0 and residual.get(jnode, {}).get(cnode) == 1:
                assignments.append((candidate, job, score_table[candidate][job]))

    return flow, sorted(assignments, key=lambda x: x[2], reverse=True)
